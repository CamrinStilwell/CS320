/*
 * Author: Camrin Stilwell
 * Date: 7/16/2023
 * Course ID: CS 320
 * Description:The following code is used to test Contact.java
 * which makes sure each object is unique based on the contact ID
 * can not be longer than 10 chars and or null, first name can not be 
 * longer than 10 char and or null, last name can no be longer than
 * 10 char and or null, phone number can not be longer than 10 char and
 * or null, and address is no longer than 30 char and or null. 
 */

package Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

	Contact contact = new Contact("12345","First","Last","000000","Test Ave. XX");
	
	@Test
	void getContactID() {
	assertEquals("12345", contact.getContactID());
	}
	
	@Test
	void getFirstName() {
		assertEquals("First", contact.getFirstName());
	}
	
	@Test
	void getLastName() {
		assertEquals("Last", contact.getLastName());
	}
	
	@Test
	void getPhoneNum() {
		assertEquals("000000", contact.getPhoneNum());
	}
	
	@Test
	void getAddress() {
		assertEquals("Test Ave. XX", contact.getAddress());
	}
	
	@Test
	void testtoString() {
		assertEquals("Contact [ID:12345, Name: First Last, Phone Number:000000, Address: Test Ave. XX]", contact.toString());
	}
}
