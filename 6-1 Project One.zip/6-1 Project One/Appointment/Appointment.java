/*
 * Author: Camrin Stilwell
 * Date: 7/30/2023
 * Course ID: CS 320
 * Description: Appointment object much have all required
 * elements (ID, Date, Description). ID string cannot be 
 * longer than 10 characters, null, and or updatable. Dates can
 * not be in the past and or null. String Descriptions cannot 
 * be longer than 50 characters and or null. 
 */

import java.util.Date;

public class Appointment {
	
private String id;
private Date apptDate;
private String desc;

private Appointment(String id, Date apptDate, String desc) {
	this.id = id;
	this.apptDate = apptDate;
	this.desc = desc;
}

public static Appointment bookAppt(String id, Date apptDate, String desc) {
	
	if(id.length() > 10 || id == null) {
		System.out.println("Invalid ID");
		return null;
	}
	if(apptDate == null || apptDate.before(new Date())) {
		System.out.println("Invalid Appointment Date");
		return null;
	}
	if(desc.length() > 50 || desc == null) {
		System.out.println("Invalid Description");
		return null;
	}
	
	return new Appointment(id, apptDate, desc);
}

public Date getApptDate() {
	return apptDate;
}
public void setApptDate(Date apptDate) {
	this.apptDate = apptDate;
}
public String getDesc() {
	return desc;
}
public void setDesc(String desc) {
	this.desc = desc;
}
public String getId() {
	return id;
}

}
