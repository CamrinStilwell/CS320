/*
 * Author: Camrin Stilwell
 * Date: 7/23/2023
 * Course ID: CS 320
 * Description: The following code contains the task object that requires
 * that the ID string will not be longer than 10 char and not null, the name string
 * will not be longer than 20 char and not null, and the description will not be longer
 * than 50 char and not null. 
 */

package taskService;

public class Task {
	
private String ID;
private String Name;
private String Desc;
		
public task(String id, String name, String desc) {
	
	if(id.length() > 10 || id == null) {
		throw new illegalArgumentException("Invalid ID");	
	}
	if(name.length() > 20 || name == null) {
		throw new illegalArgumentException("Invalid Name");
	}
	if(desc.length() > 50 || desc == null) {
		throw new illegalArgumentException("Invalid Description");
	}
	
this.ID = id;
this.Name = name;
this.Desc = desc;
}

public String getID() {
	return ID;
}

public String getName() {
	return Name;
}

public String getDesc() {
	return Desc;
}
public void updateName(String name) {
	this.Name = name;
}

public void updateDesc(String desc) {
	this.Desc = desc;
}
	
}
