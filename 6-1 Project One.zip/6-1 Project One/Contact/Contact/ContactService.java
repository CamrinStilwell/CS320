/*
 * Author: Camrin Stilwell
 * Date: 7/16/2023
 * Course ID: CS 320
 * Description: The following code reflects the requirements needed
 * for Contacts given data to function as a service. It will be able
 * to add, delete, and update contacts per contact ID. It is also
 * possible to update the first name, last name, phone number, and
 * address.
 */

package Contact;
import java.util.ArrayList;

public class ContactService {

	private ArrayList<Contact> contacts;
	
	public ContactService() {
		
		contacts = new ArrayList<>();
	}
	
	public boolean addContact(Contact contact) {
		boolean isPresent = false;
		
		for (Contact contactList:contacts) {
			
			if(contactList.equals(contact)) {
				
				isPresent = true;
			}
		}
		
		if(!isPresent) {
			
			contacts.add(contact);
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean deleteContact(String contactID) {
		
		for(Contact contactList:contacts) {
			
			if(contactList.getContactID().equals(contactID)) {
				
				contacts.remove(contactList);
				return true;
			}
		}
		return false;
	}
	
	public boolean updateContact(String contactID, String firstName, String lastName, String phoneNum, String address) {
		
		for(Contact contactList:contacts) {
			
			if(contactList.getContactID().equals(contactID)) {
				
				if(!firstName.equals("")&&!(firstName.length()>10)) {
					
					contactList.setFirstName(firstName);
				}
				if(!lastName.equals("")&&!(lastName.length()>10)) {
					
					contactList.setFirstName(lastName);
				}
				if(!phoneNum.equals("")&&!(phoneNum.length()>10)) {
					
					contactList.setFirstName(phoneNum);
				}
				if(!address.equals("")&&!(address.length()>30)) {
					
					contactList.setFirstName(address);
				}
				return true;
			}
		}
		return false;
	}
}
