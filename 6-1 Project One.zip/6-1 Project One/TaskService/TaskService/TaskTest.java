/*
 * Author: Camrin Stilwell
 * Date: 7/23/2023
 * Course ID: CS 320
 * Description: The following code tests task.java functionality.
 */
package taskService;
public class TaskTest {
@test public void createTestTask() {
	Task task = new Task("12345","Test","This is a test");
}
}
