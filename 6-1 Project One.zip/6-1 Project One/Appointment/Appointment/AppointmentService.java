/*
 * Author: Camrin Stilwell
 * Date: 7/30/2023
 * Course ID: CS 320
 * Description: Appointment service will provide functions
 * so that appointments can be added or deleted per ID.
 */

import java.util.ArrayList;
import java.util.Date;

public class AppointmentService {
ArrayList<Appointment> data;

public AppointmentService() {
	data = new ArrayList<Appointment>();
}

public boolean addAppt(String id, Date apptDate, String desc) {
	Appointment temp = Appointment.bookAppt(id, apptDate, desc);
	
	if (temp != null) {
		if(!data.contains(temp)) {
			data.add(temp);
			return true;
		}
	}
	return false;
}

public boolean deleteAppt(String id) {
	for(Appointment temp: data) {
		if(temp.getId().equals(id)) {
			data.remove(temp);
			return true;
		}
	}
	return false;
}
}
