/*
 * Author: Camrin Stilwell
 * Date: 7/23/2023
 * Course ID: CS 320
 * Description: The following code contains the task services
 * where tasks can be added or deleted, and task fields can be 
 * updated, only allowing name and description to be updated.
 */

package taskService;
import java.util.ArrayList;

public class taskService {

public static ArrayList<task>tasks = new ArrayList<>();

public static boolean addTask(task task) {
	boolean currentTask = false;
	
	for (task taskList: tasks) {
		if(taskList.getID().equals(task.getID())) {
			currentTask = true;
		}
	}
	if (!alreadyTask) {
		task.add(task);
	}
	return currentTask;
}

public static boolean deleteTask(task task) {
	for(task taskList: tasks) {
		if(taskList.getId().equals(task.getID())) {
			tasks.remove(task);
			return true;
		}
	}
	return false;
}
public static boolean updateTask(task task) {
	for(task taskList: tasks) {
		if(taskList.getID().equals(task.getID())) {
			taskList.updateName(task.getName());
			taskList.updateDesc(task.getDesc());
			return true;
		}
	}
	return false;
}
}
