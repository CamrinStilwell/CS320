/*
 * Author: Camrin Stilwell
 * Date: 7/30/2023
 * Course ID: CS 320
 * Description: Tests AppointmentService.java to make
 * sure appointments can be added or deleted with 
 * unique appointment ID.
 */

import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;
import org.junit.Before;

public class AppointmentServiceTest {

	private AppointmentService apptService;
	
	@Before void setUp() {
		apptService = new AppointmentService();
	}
	
	@Test void testAddAppt() {
		Appointment appt = new Appointment("12345", new Date(), "Appointment 1");
		assertTrue(apptService.addAppt(appt));
	}
	
	@Test void testDeleteAppt() {
		Appointment appt = new Appointment("12345", new Date(), "Appointment 1");
		apptService.addAppt(appt);
		assertTrue(apptService.deleteAppt("12345"));
	}
}
