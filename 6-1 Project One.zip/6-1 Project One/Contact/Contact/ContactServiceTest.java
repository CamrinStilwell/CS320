/*
 * Author: Camrin Stilwell
 * Date: 7/16/2023
 * Course ID: CS 320
 * Description: The following code tests ContactService.java on
 * its functionalities of adding, deleting, and updating contacts
 * per contact ID. Also makes sure that the first name, last name, 
 * phone number, and address can be updated.  
 */

package Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

	@Test
	
	public void testAdd() {
		ContactService testCS = new ContactService();
		
		Contact test1 = new Contact("12345","First","Last","000000","Test Ave. XX");
		assertEquals(true,testCS.addContact(test1));
	}
	@Test
	
	public void testDelete() {
ContactService testCS = new ContactService();
		
		Contact test1 = new Contact("00001","Ace","Card","100000","Test Ave. XX");
		Contact test2 = new Contact("00002","Spades","Card","010000","Test Ave. XX");
		Contact test3 = new Contact("00003","Hearts","Card","001000","Test Ave. XX");
		
		testCS.addContact(test1);
		testCS.addContact(test2);
		testCS.addContact(test3);
		
		assertEquals(true, testCS.deleteContact("00001"));
		assertEquals(false, testCS.deleteContact("00002"));
		assertEquals(false, testCS.deleteContact("00001"));
		
	}
	@Test
	
	public void testUpdate() {
		
		ContactService testCS = new ContactService();
		
		Contact test1 = new Contact("00001","Ace","Card","100000","Test Ave. XX");
		Contact test2 = new Contact("00002","Spades","Card","010000","Test Ave. XX");
		Contact test3 = new Contact("00003","Hearts","Card","001000","Test Ave. XX");
		
		testCS.addContact(test1);
		testCS.addContact(test2);
		testCS.addContact(test3);
		
		assertEquals(false, testCS.updateContact("00004", "Clubs", "Card", "000100", "Test Ave. XX"));
		assertEquals(true, testCS.updateContact("00003", "Spades", "Card", "001000", "Test Ave. XX"));
		
	}
}
