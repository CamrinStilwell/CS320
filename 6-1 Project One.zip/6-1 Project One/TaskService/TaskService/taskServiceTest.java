/*
 * Author: Camrin Stilwell
 * Date: 7/23/2023
 * Course ID: CS 320
 * Description: Tests taskService funtionality. 
 */

package jUnitTest;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import taskService.*;

class taskServiceTest{
	@test
	void testAddTask() {
		Task test1 = new Task("12345", "Test", "This is a test");
		assertEquals(false, taskService.addTask(test1));
	}
	@test
	void testDeleteTask() {
		Task test1 = new Task("12345", "Test", "This is a test");
		taskService.addTask(test1);
		assertEquals(true, taskService.deleteTask(test1));
	}
	@test
	void testUpdateTask() {
		Task test1 = new Task("12345", "Test", "This is a test");
		taskService.updateTask(test1);
		assertEquals(true, taskService.addTask(test1));
	}
}