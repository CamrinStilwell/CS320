/*
 * Author: Camrin Stilwell
 * Date: 7/30/2023
 * Course ID: CS 320
 * Description: Tests Appointment.java to make sure
 * Appointments can be booked and the required Date, ID,
 * and description are provided.
 */

import java.util.Date;
import org.junit.Test;
import static org.junit.Assert.*;

public class AppointmentTest {

	@Test 
	void testBookAppt() {
		Appointment appointment = new Appointment("12345", new Date(), "Description");
		assertNotNull(appointment);
	}
	@Test 
	void testApptDate() {
		Date appointment = new Date();
		Appointment appointment = new Appointment("12345", apptDate, "Description");
		assertEquals(apptDate, appointment.getApptDate());
		}
	@Test 
	void testApptID() {
		Appointment appointment = new Appointment("12345", newDate(), "Description");
		assertEquals("12345", appointment.getId());
		}
	@Test 
	void testApptDesc() {
		Appointment appointment = new Appointment("12345", apptDate, "Description");
		assertEquals("Description", appointment.getDesc());
		}
		
	}
}
